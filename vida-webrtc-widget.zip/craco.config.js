// craco.config.js
module.exports = {
  devServer: {
    port: 3001
  }
}